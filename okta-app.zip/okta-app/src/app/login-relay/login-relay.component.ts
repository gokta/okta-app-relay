import { Component, OnInit } from '@angular/core';
import { OktaAuthService } from '@okta/okta-angular';


@Component({
  selector: 'app-login-relay',
  templateUrl: './login-relay.component.html',
  styleUrls: ['./login-relay.component.css']
})
export class LoginRelayComponent implements OnInit {
  authService;

  constructor(oktaAuth: OktaAuthService) { 
    this.authService = oktaAuth;
  }

  ngOnInit(): void {
    this.authService.token.getWithRedirect({
      responseType: 'id_token',
      state: 'http://localhost:4200/protected'
    }).then(x => {
      console.log(x)
    })
  }

}
