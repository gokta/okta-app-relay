import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginRelayComponent } from './login-relay.component';

describe('LoginRelayComponent', () => {
  let component: LoginRelayComponent;
  let fixture: ComponentFixture<LoginRelayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginRelayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginRelayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
